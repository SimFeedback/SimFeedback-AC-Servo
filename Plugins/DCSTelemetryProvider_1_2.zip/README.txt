DCS Telemetry Provider for SimFeedback v1.2

Installation:

1) Exit SimFeedback if running

2) Extract this zip into SimFeedback directory.

3) Copy ext\dcs\Export.lua to C:\Users\USER_NAME\Saved Games\DCS\Scripts\Export.lua

4) Run remove_blocking.bat as admin