Forza Horizon 4 and Forza Motorsport 7 SimFeedback TelemetryProvider

Installation:

- Close SimFeedback
- Extract the zip file to SimFeedback installation folder.
- Run WindowsLoopbackManager.exe as admin and add your applications.
- Run remove_blocking.bat as admin
- Start SimFeedback


