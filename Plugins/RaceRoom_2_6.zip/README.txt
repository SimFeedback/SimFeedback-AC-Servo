RaceRoom 2.6v TelemetryProvider


Installation:

- Close SimFeedback
- Extract the zip file to SimFeedback installation folder.
- Run remove_blocking.bat as admin
- Start SimFeedback

