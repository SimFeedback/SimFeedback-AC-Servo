Install: Copy zip file to SimFeedback Folder and extract.

This is an early Release, plz be careful und make sure your rig can move freely.
It is only testet with one coaster Colossus.

If you are going to test other rides turn down the overall intensity.
It is unknown how it behaves in loopings or screws!!!

Take Care and Merry Christmas!