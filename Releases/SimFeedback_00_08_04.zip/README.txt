﻿Installation

Make a folder, name it like you want, maybe SimFeedback ;).
Unzip to this folder.
Run the script "remove_blocking.bat" by double clicking.
Start SimFeedbackStart.exe
Enjoy!