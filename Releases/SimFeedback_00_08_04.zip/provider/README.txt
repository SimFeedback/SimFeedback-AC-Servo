﻿Put your custom Telemetry Provider DLL here.

Telemetry Provider will link the game to SimFeedback and provide telemetry information to create the motion cues.
If you want to create your own Provider for your favorite game.
Have a look in the Wiki:
https://github.com/SimFeedback/SimFeedback-AC-Servo/wiki


